Vitorize Web release — 2026-09-21 (responsive mobile audit)

This package contains only the Web publish output. API and database are unchanged.

Included changes
================
- Final mobile responsive review across the customer-facing routes in light and dark themes.
- Dark FAQ disclosure controls use a subtle branded surface instead of a solid mint disc.
- The homepage and standalone FAQ now keep the same dark-theme visual hierarchy.

Deployment
==========
1. Back up the current Web directory and production appsettings.Production.json.
2. Deploy the contents of Web/ to the Web application root.
3. Preserve the server-specific production configuration and App_Data.
4. Recycle the Web application pool and clear static-asset/browser cache.

Verification
============
- Release publish completed successfully.
- Web Release build completed with 0 warnings and 0 errors.
- Full test suite: 1084 passed, 0 failed.
- Customer-facing mobile routes were visually checked in light and dark themes.
