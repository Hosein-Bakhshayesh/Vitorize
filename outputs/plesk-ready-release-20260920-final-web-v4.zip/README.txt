Vitorize Web release - 2026-09-20 (final web v4)

This package contains only the Web publish output. API and database are unchanged.

Additional v4 fix
=================
- Category mega-menu child and leaf category labels stay on one line.
- Child-category columns now use auto-fit, so unused grid columns collapse and the available panel width is used instead of forcing narrow wrapped labels.
- Root category labels remain on one line as fixed in v3.

Deployment
==========
1. Back up the current Web directory and production appsettings.Production.json.
2. Deploy the contents of Web/ to the Web application root.
3. Preserve the server-specific production configuration.
4. Recycle the Web application pool and clear static-asset/browser cache.

Verification
============
- Release build: succeeded with 0 warnings and 0 errors.
- StorefrontShellConsistencyTests: 3 passed, 0 failed.
- Visually verified in dark mode using live API data and the "کارت های مجازی" category.
