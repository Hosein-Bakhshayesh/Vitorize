Vitorize Web release - 2026-09-20 (final web v3)

Contents
========
- Web/: ASP.NET Core Web publish output for Plesk/IIS.
- The API and database packages are intentionally not included because this release only changes Vitorize.Web.

Latest verified fixes included
==============================
- Desktop category mega-menu root titles stay on one line and the side column has enough width for long Persian labels.
- Homepage dark/light presentation fixes, category and review surfaces, buttons and text contrast.
- Continuous clickable brand marquee with no empty tail.
- Homepage product cards, mobile eight-product listing and the more-products action.
- Storefront icon, touch-feedback, header/footer and theme consistency fixes.

Deployment
==========
1. Back up the current web application directory and production appsettings.Production.json.
2. Deploy the contents of Web/ to the Web application root.
3. Keep the server-specific appsettings.Production.json values.
4. Recycle the Web application pool and clear any reverse-proxy/browser static-asset cache.

Verification
============
- Release build: succeeded with 0 warnings and 0 errors.
- StorefrontShellConsistencyTests: 2 passed, 0 failed.
- Visual check: homepage dark theme and opened desktop category mega-menu verified against live production API data.
