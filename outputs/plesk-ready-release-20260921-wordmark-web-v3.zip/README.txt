Vitorize Web release — 2026-09-21

Scope: Web only. API and database were not changed.

Deployment:
1. Back up the currently deployed Web files.
2. Extract every file and folder from this package into the Web application's Plesk document root.
3. Preserve the production appsettings and App_Data files unless intentionally replacing them.
4. Restart the Web application pool.

This release includes wwwroot/images/vitorize-wordmark.png, used by the English logo in the storefront header and footer.
