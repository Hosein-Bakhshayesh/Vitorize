Vitorize Web release — 2026-09-21

Scope: Web only. No API or database migration is included.

Deployment:
1. Back up the current Web deployment.
2. Extract every file and folder from this ZIP into the Web application's Plesk document root.
3. Keep production appsettings and App_Data unless you intentionally replace them.
4. Restart the Web application pool.

Included storefront fixes: English Vitorize wordmark, theme-aware account avatar,
responsive dark-theme improvements, category child hover popovers, and a seamless
brand rail that pauses on hover/focus.
